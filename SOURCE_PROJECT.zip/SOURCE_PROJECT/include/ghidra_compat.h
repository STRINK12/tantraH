﻿#pragma once
#include "recovered_types.h"
#include <intrin.h>
#include <mbstring.h>
#include <stdint.h>

// GHIDRA compatibility helpers - diagnostic reconstruction layer.
typedef int (__cdecl recovered_code)(...);
#undef code
#define code recovered_code

static __forceinline uint32_t GH_CONCAT11(uint8_t hi,uint8_t lo){return ((uint32_t)hi<<8)|lo;}
static __forceinline uint32_t GH_CONCAT12(uint8_t hi,uint16_t lo){return ((uint32_t)hi<<16)|lo;}
static __forceinline uint32_t GH_CONCAT21(uint16_t hi,uint8_t lo){return ((uint32_t)hi<<8)|lo;}
static __forceinline uint32_t GH_CONCAT22(uint16_t hi,uint16_t lo){return ((uint32_t)hi<<16)|lo;}
#define CONCAT11(a,b) GH_CONCAT11((uint8_t)(a),(uint8_t)(b))
#define CONCAT12(a,b) GH_CONCAT12((uint8_t)(a),(uint16_t)(b))
#define CONCAT21(a,b) GH_CONCAT21((uint16_t)(a),(uint8_t)(b))
#define CONCAT22(a,b) GH_CONCAT22((uint16_t)(a),(uint16_t)(b))

// 24-bit values emitted by Ghidra.
#pragma pack(push,1)
struct recovered_uint3 { unsigned char b[3]; recovered_uint3():b{0,0,0}{} recovered_uint3(uint32_t v){b[0]=(unsigned char)v;b[1]=(unsigned char)(v>>8);b[2]=(unsigned char)(v>>16);} operator uint32_t() const{return (uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16);} };
struct recovered_int3 { unsigned char b[3]; recovered_int3():b{0,0,0}{} recovered_int3(int32_t v){b[0]=(unsigned char)v;b[1]=(unsigned char)(v>>8);b[2]=(unsigned char)(v>>16);} operator int32_t() const{uint32_t v=(uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16);return (v&0x800000)?(int32_t)(v|0xff000000):(int32_t)v;} };
#pragma pack(pop)
#undef uint3
#define uint3 recovered_uint3
#define int3 recovered_int3
static __forceinline int32_t GH_CONCAT31(recovered_uint3 hi,uint8_t lo){return (int32_t)(((uint32_t)hi<<8)|lo);}
static __forceinline int32_t GH_CONCAT31(recovered_int3 hi,uint8_t lo){return (int32_t)(((uint32_t)(int32_t)hi<<8)|lo);}
#define CONCAT31(a,b) GH_CONCAT31((a),(uint8_t)(b))

// cpuid wrappers used by decompiler output.
static __forceinline void cpuid_Version_info(int leaf){int r[4];__cpuid(r,leaf);}
static __forceinline uintptr_t cpuid(int leaf){static int r[4];__cpuid(r,leaf);return (uintptr_t)&r[0];}
