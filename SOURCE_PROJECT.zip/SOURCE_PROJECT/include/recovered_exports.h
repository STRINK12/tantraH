#pragma once
/* Recovered named exports. Signatures remain in recovered cpp until ABI is proven. */
// HT_hrDestory3DMgr
// HT_pCreate3DMgr
