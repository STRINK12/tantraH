#pragma once
#include <windows.h>
#include <stdint.h>
typedef uint8_t undefined1; typedef uint16_t undefined2; typedef uint32_t undefined4; typedef uint64_t undefined8;
typedef unsigned char byte; typedef unsigned char uchar; typedef unsigned short ushort; typedef unsigned int uint; typedef unsigned long ulong;
typedef unsigned char uint1; typedef unsigned short uint2; struct uint3 { unsigned char b[3]; };
typedef long double float10; typedef void code;
